#pragma once
#include <lib/subghz/devices/types.h>

#define SUBGHZ_DEVICE_CC1101_EXT_NAME "cc1101_ext"

typedef struct SubGhzDeviceCC1101Ext SubGhzDeviceCC1101Ext;

const FlipperAppPluginDescriptor* subghz_device_cc1101_ext_ep();
