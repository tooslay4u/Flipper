#pragma once
#include "cligui_main_i.h"

extern void console_output_input_handler(CliguiApp*, InputEvent*);