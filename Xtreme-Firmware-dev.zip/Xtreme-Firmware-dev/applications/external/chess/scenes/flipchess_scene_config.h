ADD_SCENE(flipchess, startscreen, Startscreen)
ADD_SCENE(flipchess, menu, Menu)
ADD_SCENE(flipchess, scene_1, Scene_1)
ADD_SCENE(flipchess, settings, Settings)