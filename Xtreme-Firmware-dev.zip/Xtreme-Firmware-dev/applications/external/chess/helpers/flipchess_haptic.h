#include <notification/notification_messages.h>

void flipchess_play_happy_bump(void* context);

void flipchess_play_bad_bump(void* context);

void flipchess_play_long_bump(void* context);
