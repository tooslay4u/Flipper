#pragma once

typedef enum {
    FlipChessCustomEventStartscreenUp,
    FlipChessCustomEventStartscreenDown,
    FlipChessCustomEventStartscreenLeft,
    FlipChessCustomEventStartscreenRight,
    FlipChessCustomEventStartscreenOk,
    FlipChessCustomEventStartscreenBack,
    FlipChessCustomEventScene1Up,
    FlipChessCustomEventScene1Down,
    FlipChessCustomEventScene1Left,
    FlipChessCustomEventScene1Right,
    FlipChessCustomEventScene1Ok,
    FlipChessCustomEventScene1Back,
} FlipChessCustomEvent;