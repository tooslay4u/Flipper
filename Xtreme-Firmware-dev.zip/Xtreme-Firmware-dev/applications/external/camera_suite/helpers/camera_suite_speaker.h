#define NOTE_INPUT 587.33f

void camera_suite_play_input_sound(void* context);

void camera_suite_stop_all_sound(void* context);
