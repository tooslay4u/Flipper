void camera_suite_led_set_rgb(void* context, int red, int green, int blue);

void camera_suite_led_reset(void* context);
