#include <notification/notification_messages.h>

void camera_suite_play_happy_bump(void* context);

void camera_suite_play_bad_bump(void* context);

void camera_suite_play_long_bump(void* context);
