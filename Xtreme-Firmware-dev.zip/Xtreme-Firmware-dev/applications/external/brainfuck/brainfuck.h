#pragma once

typedef struct BFApp BFApp;