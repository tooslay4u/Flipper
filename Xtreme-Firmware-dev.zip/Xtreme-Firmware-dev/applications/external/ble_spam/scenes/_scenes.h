ADD_SCENE(main, Main)
ADD_SCENE(config, Config)
#include "../protocols/_scenes.h"
