ADD_SCENE(file_browser, start, Start)
ADD_SCENE(file_browser, browser, Browser)
ADD_SCENE(file_browser, result, Result)
